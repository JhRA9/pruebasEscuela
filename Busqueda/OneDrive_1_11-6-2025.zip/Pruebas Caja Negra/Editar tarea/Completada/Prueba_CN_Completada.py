from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
import time

driver = webdriver.Chrome()

try:
    # Iniciar sesión como administrador
    driver.get("http://localhost/proyectoEscuela/login/index.php")
    driver.find_element(By.NAME, "email").send_keys("admin@admin.com")
    driver.find_element(By.NAME, "password").send_keys("123", Keys.ENTER)
    nuevo_estado = "Completada"

    try:
        
        # Navegar a la página de edición de tarea
        driver.get("http://localhost/proyectoEscuela/admin/tareas/edit.php?id=64")
        time.sleep(5)

        # Marcar la tarea como completada
        Select(driver.find_element(By.NAME, "estado")).select_by_visible_text(nuevo_estado)
        driver.find_element(By.XPATH, "//button[@type='submit']").click()
        driver.save_screenshot("C:/Users/casas/Documents/Docs Santiago/Universidad/Ing. Software 3/Pruebas/Prueba Caja Negra/Editar tarea/Completada/despues.png")
        time.sleep(10)

        # Verificar que la edición fue exitosa
        if "La tarea se actualizó" in driver.page_source:
            print("✅ Prueba exitosa: tarea editada correctamente.")
        else:
            print("❌ No se detectó mensaje de éxito.")
        
    except Exception as e:
        print("❌ Prueba fallida", str(e))

except Exception as e:
    print("❌ Error general durante la prueba:", str(e))

finally:
    driver.quit()