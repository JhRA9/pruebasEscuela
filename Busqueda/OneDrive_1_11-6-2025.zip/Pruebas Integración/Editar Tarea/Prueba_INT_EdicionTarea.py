from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome()

try:
    # Login como administrador
    driver.get("http://localhost/proyectoEscuela/login/index.php")
    driver.find_element(By.NAME, "email").send_keys("admin@admin.com")
    driver.find_element(By.NAME, "password").send_keys("123", Keys.ENTER)
    time.sleep(3)

    # ✅ FLUJO 1: Edición válida
    try:
        # Datos de la tarea a editar
        nuevo_titulo = "Prueba de anatomia"
        nuevo_descripccion = "Chúzate un pulmón a ver si duele"
        nueva_fecha = "2025-05-10"
        nueva_hora = "23:59:00"
        valor_materia = "4"
        nuevo_estado = "Pendiente"

        driver.get("http://localhost/proyectoEscuela/admin/tareas/edit.php?id=64")
        driver.find_element(By.NAME, "titulo").clear()
        driver.find_element(By.NAME, "titulo").send_keys(nuevo_titulo)
        driver.find_element(By.NAME, "descripcion").clear()
        driver.find_element(By.NAME, "descripcion").send_keys(nuevo_descripccion)
        driver.execute_script("document.getElementsByName('fecha_entrega')[0].value = arguments[0]", nueva_fecha)
        driver.find_element(By.NAME, "hora_entrega").send_keys(Keys.CONTROL + "a", nueva_hora)
        Select(driver.find_element(By.NAME, "id_materia")).select_by_value(valor_materia)
        Select(driver.find_element(By.NAME, "estado")).select_by_visible_text(nuevo_estado)
        driver.find_element(By.XPATH, "//button[@type='submit']").click()
        time.sleep(10)

        print("✅ Flujo 1: Edición válida realizada.")
    except Exception as e:
        print("❌ Flujo 1: Falló al editar el usuario:", str(e))

    # FLUJO 2: Confirmación post-edición
    try:
        time.sleep(5) 
        mensaje_confirmacion = driver.page_source
        if "actualizado correctamente" in mensaje_confirmacion or "modificado" in mensaje_confirmacion:
            print("✅ Flujo 2: Mensaje de confirmación visible.")
        else:
            print("⚠️ Flujo 2: No se encontró mensaje de confirmación, verificar manualmente.")
    except Exception as e:
        print("❌ Flujo 2: Error al verificar mensaje de confirmación:", str(e))

    # FLUJO 3: Verificación en tabla
    try:
        driver.get("http://localhost/proyectoEscuela/admin/tareas/index.php")
        WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "example1"))
        )
        time.sleep(5)

        filas = driver.find_elements(By.XPATH, "//table[@id='example1']//tbody//tr")

        tarea_encontrada = any(nuevo_titulo in fila.text and nuevo_descripccion in fila.text for fila in filas)

        if tarea_encontrada:
            print(f"✅ Flujo 3: Titulo '{nuevo_titulo}' actualizado encontrado en la tabla.")
        else:
            print(f"❌ Flujo 3: Titulo '{nuevo_titulo}' no aparece en la tabla.")
    except Exception as e:
        print("❌ Flujo 3: Error al buscar Titulo en la tabla:", str(e))

except Exception as e:
    print("❌ Error general durante la prueba:", str(e))

finally:
    driver.quit()